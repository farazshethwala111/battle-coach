package com.faraz.battlecoach

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    private val projectionRequest = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(36, 48, 36, 36)
            gravity = Gravity.CENTER_HORIZONTAL
        }
        status = TextView(this).apply {
            text = "Faraz Battle Coach — Live architecture\n\nSafety-first: screen capture only. No game memory access, auto-taps, or card deployment."
            textSize = 17f
        }
        val overlayButton = Button(this).apply {
            text = "1. Allow floating overlay"
            setOnClickListener {
                if (!Settings.canDrawOverlays(this@MainActivity)) {
                    val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName"))
                    startActivity(i)
                } else status.text = "Overlay permission granted."
            }
        }
        val startButton = Button(this).apply {
            text = "2. Start live screen capture"
            setOnClickListener { requestCapture() }
        }
        val stopButton = Button(this).apply {
            text = "Stop coach"
            setOnClickListener { stopService(Intent(this@MainActivity, CaptureService::class.java)); status.text = "Coach stopped." }
        }
        layout.addView(status); layout.addView(overlayButton); layout.addView(startButton); layout.addView(stopButton)
        setContentView(layout)
        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(android.Manifest.permission.POST_NOTIFICATIONS), 4103)
        }
    }

    private fun requestCapture() {
        if (!Settings.canDrawOverlays(this)) {
            status.text = "First allow floating overlay permission."
            return
        }
        val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        @Suppress("DEPRECATION")
        startActivityForResult(manager.createScreenCaptureIntent(), projectionRequest)
    }

    @Deprecated("Android MediaProjection consent result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == RESULT_OK && data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_DATA, data)
            }
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service) else startService(service)
            status.text = "Live capture started. Open Clash Royale; coach overlay will remain visible."
        } else status.text = "Screen capture permission was not granted."
    }
}

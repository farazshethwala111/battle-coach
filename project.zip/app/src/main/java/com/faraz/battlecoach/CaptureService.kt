package com.faraz.battlecoach

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView

/**
 * Capture pipeline architecture:
 * MediaProjection -> VirtualDisplay -> ImageReader -> 200ms frame gate (5 fps)
 * -> BattleFrameAnalyzer -> floating recommendation.
 *
 * BattleFrameAnalyzer is deliberately a safe stub. A validated card-detection model
 * and elixir/hand state estimator must be integrated before this can give real advice.
 */
class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_DATA = "projection_data"
        private const val CHANNEL = "faraz_coach_capture"
        private const val NOTIFICATION_ID = 51
        private const val FRAME_INTERVAL_MS = 200L
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var overlay: TextView? = null
    private var windowManager: WindowManager? = null
    private var lastFrameAt = 0L
    private var frameCount = 0
    private var worker: Handler? = null
    private var thread: HandlerThread? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val analyzer = BattleFrameAnalyzer()

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
        thread = HandlerThread("BattleFrameWorker").also { it.start() }
        worker = Handler(thread!!.looper)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startForeground(NOTIFICATION_ID, buildNotification())
        val resultCode = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            ?: Activity.RESULT_CANCELED
        @Suppress("DEPRECATION")
        val data = if (Build.VERSION.SDK_INT >= 33) intent?.getParcelableExtra(EXTRA_DATA, Intent::class.java)
                   else intent?.getParcelableExtra(EXTRA_DATA) as? Intent
        if (resultCode != Activity.RESULT_OK || data == null) {
            updateOverlay("Capture permission missing. Stop and retry.")
            stopSelf()
            return START_NOT_STICKY
        }
        try {
            val manager = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            projection = manager.getMediaProjection(resultCode, data)
            projection?.registerCallback(object : MediaProjection.Callback() {
                override fun onStop() { stopSelf() }
            }, worker)
            startCapture()
            showOverlay()
        } catch (e: Exception) {
            updateOverlay("Capture could not start: ${e.javaClass.simpleName}")
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun startCapture() {
        val metrics = resources.displayMetrics
        val width = metrics.widthPixels.coerceAtMost(1080)
        val height = metrics.heightPixels.coerceAtMost(2400)
        reader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source ->
            var image: Image? = null
            try {
                image = source.acquireLatestImage()
                val now = System.currentTimeMillis()
                if (image != null && now - lastFrameAt >= FRAME_INTERVAL_MS) {
                    lastFrameAt = now
                    frameCount++
                    val result = analyzer.analyze(image, frameCount)
                    updateOverlay(result)
                }
            } catch (_: Exception) {
                updateOverlay("Frame read issue — retrying")
            } finally { image?.close() }
        }, worker)
        virtualDisplay = projection?.createVirtualDisplay(
            "FarazBattleCoachDisplay", width, height, metrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, worker
        )
    }

    private fun showOverlay() {
        if (!Settings.canDrawOverlays(this)) return
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        val view = TextView(this).apply {
            text = "FARAZ COACH\nScreen capture active\nWaiting for detector model…"
            textSize = 13f; setTextColor(0xFFFFFFFF.toInt())
            setPadding(22, 16, 22, 16); setBackgroundColor(0xEE14243A.toInt())
        }
        overlay = view
        val type = if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                   else WindowManager.LayoutParams.TYPE_PHONE
        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            type, WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.END; x = 12; y = 150 }
        try { windowManager?.addView(view, params) } catch (_: Exception) {}
    }

    private fun updateOverlay(message: String) {
        mainHandler.post { overlay?.text = "FARAZ COACH\n$message" }
    }

    private fun buildNotification(): Notification {
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL) else Notification.Builder(this)
        return builder.setContentTitle("Faraz Battle Coach")
            .setContentText("Screen analysis session active — tap Stop in the app to end.")
            .setSmallIcon(android.R.drawable.ic_media_play)
            .setOngoing(true).build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val channel = NotificationChannel(CHANNEL, "Battle Coach screen capture", NotificationManager.IMPORTANCE_LOW)
            (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        virtualDisplay?.release(); reader?.close(); projection?.stop()
        thread?.quitSafely()
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
}

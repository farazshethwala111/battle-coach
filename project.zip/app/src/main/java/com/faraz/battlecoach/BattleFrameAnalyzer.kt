package com.faraz.battlecoach

import android.media.Image

/**
 * Replace this stub with a tested on-device computer-vision pipeline:
 * 1) Crop arena region and normalize orientation.
 * 2) Detect card/troop sprites with a licensed/owned TFLite model.
 * 3) Track detections across frames to reduce false positives.
 * 4) Estimate elixir only as a confidence-scored estimate from the visible bar.
 * 5) Infer opponent card cycle only from cards actually observed.
 *
 * Never infer exact elixir or a card from one ambiguous frame.
 */
class BattleFrameAnalyzer {
    fun analyze(image: Image, frameNumber: Int): String {
        // Frame arrives at a maximum of 5 fps. Real recognition is not yet connected.
        return "Screen frames received: $frameNumber\nDetector model not connected yet."
    }
}

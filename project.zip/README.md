# Faraz Battle Coach — Live Android Architecture v0.1

Target device: iQOO Neo 10R  
Target analysis cadence: 5 frames/second (200 ms minimum interval)  
Guidance: floating overlay + Hinglish

## What this project implements
- Android MediaProjection permission flow for user-consented screen capture.
- Foreground service with mediaProjection service type.
- ImageReader / VirtualDisplay capture pipeline.
- 200 ms frame gate (maximum 5 sampled frames per second).
- Android system overlay permission and floating coach panel.
- Stop control in the app and persistent foreground notification.

## What is NOT implemented yet
- Real Clash Royale card recognition.
- Opponent elixir estimation / card cycle recognition.
- Strategic AI recommendations from actual frames.
The `BattleFrameAnalyzer` is intentionally a stub. The overlay will say that the detector model is not connected. Do not treat this as a functioning live strategy bot yet.

## Safety design
- No game memory/process access.
- No game file modification.
- No auto taps, touch injection, troop deployment, macros or automation.
- User manually grants Android screen-capture consent and overlay permission.
- Capture stops when the user stops the service or revokes MediaProjection.

This minimizes interference with the game but cannot guarantee Supercell policy compliance. Check the current Supercell Safe and Fair Play policy before using third-party overlays.

## Build
Open this folder in Android Studio (recent version with Android Gradle Plugin 8.7.3 support), sync Gradle, then Build > Build APK(s).
Install the debug APK on the phone. Android will prompt for overlay permission and screen capture consent.
For Android 13+, notification permission may also be requested by the OS.

## Next engineering milestone
Integrate an on-device TFLite object detector trained and validated on Clash Royale card/troop screenshots, then a temporal tracker and confidence-aware recommendation engine. Keep 5 fps sampling configurable; use adaptive inference if the iQOO device heats up or drops frames.
